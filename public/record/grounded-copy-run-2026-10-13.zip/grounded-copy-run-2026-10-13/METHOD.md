# Method and accounting

## Conditions and question selection

The answer model was gpt-6.1-sol, with explicit Medium reasoning effort and
Codex CLI 0.161.0. Each question started a fresh, ephemeral process in a
read-only sandbox. The recorded commands are in generation-settings.json.
The same 300 prompts were used in the plain and Grounded Copy conditions,
with 60 questions each from cooking, travel, money, parenting, and DIY.

The humanizer condition rewrote the plain answers to the first 20 selected
questions of each site, preserving their original order. This gives 100
matching question IDs across all three conditions. The selection is systematic
and covers these five question sites.

The questions came from the Stack Exchange dump sources listed in
data/sources.json. The archived source/build_ai_answers.py orders eligible questions by ID and
selects them at a fixed stride. The exported question records preserve the
exact prompts and identify the original posts and licenses. The human baseline
has 310 answers across those 300 questions, since some questions have more
than one retained human answer.

Grounded Copy used version 0.7.0, commit
662d90cf9392907912f2d913f78d7860c5621d53. Its session and per-turn hooks completed
in every selected execution. The recount uses that revision's unchanged checker.
Later plugin releases have changed instructions and checker behavior.

Humanizer used version 3.1.0, commit
225a6f39ac85f76ee48dbad772ea4abe4ed6c9d8. Its SKILL.md SHA-256 is
3ac977c2c963a3b483988733b57d4087b87d4d6b80a17f5d2640489c7c2f2c90.
The exact file is bundled. Each accepted prompt begins:

> Use the $humanizer skill on the text below. Return only the final rewritten text.

The original plain answer follows that line. Native invocation was approved
after three literal-name read probes failed to load the full skill. Those
probes are excluded from the accepted outputs and reported as setup overhead.
The native audits identified the full skill title and its rule 26. The audit
replies and their normalized logs are bundled under audits/.

The plain condition disabled writing plugins and hooks. Its audits reported
no loaded user writing rules. Grounded Copy's audits identified its two public
hook messages. Humanizer's native audits reported the supplied skill and no
other loaded user writing rules. Runtime headers alone establish the requested
model and effort; the audits provide the context-loading evidence.

## Performance

**Logged tokens per finished answer.** Read the last `tokens used` value in
the selected successful execution's log. Take the arithmetic mean across
the same question IDs. For write-then-rewrite, add the plain and rewrite
counts for each question before taking the mean. Retain the full precision
until presentation rounding. The public counter uses the selected attempt
specified by each answer record.

This measures printed log counters. The records have no breakdown of input,
cached input, output, and reasoning tokens, and no billing amounts. Failed
attempts sometimes have a footer and sometimes lack one. The performance
table uses selected executions; RESULTS.md reports other attempts separately.
CLI-internal reconnections can occur within an outer execution. Their individual
charges are unavailable. Report these figures as recorded token counts.

**Recorded path seconds.** Use each answer record's seconds value. For the
two-step workflow, add the plain and rewrite seconds for each question, then
take the median. Summing the two separate medians would give a different
quantity. Timings include recorded failed attempts, capacity delays, and
reconnections. Five early Grounded Copy pilot timings also include waits for
inherited Git pipes. Those values were preserved.

The conditions ran in separate batches on different days, with up to four
concurrent calls. There were no repeated or randomized interleaved runs.
Recorded execution dates are recoverable from the bundled log timestamps.
The table describes this run. It does not establish general latency or
monetary savings. Audits, setup probes, and the time spent preparing the
bundle belong to experiment overhead, outside per-answer path time.

**Answer length.** Full-answer word count splits the final answer on whitespace,
including its Markdown. Character count uses the complete final answer text.
The extracted prose count uses tools/normalize.py, copied verbatim from the
tested helper. It omits fenced code, headings, block quotes, and table rows;
removes Markdown link destinations and list markers; and retains qualifying
English paragraphs. It then counts whitespace-separated words. These measures
describe length; they do not establish factual completeness.

## Style

**Answers with a checker match.** Scan the extracted prose with the bundled
Grounded Copy 0.7.0 checker under chat. Count each answer once when it has
at least one finding, then divide by the number of answers in the condition.

**Findings per 100,000 prose words.** Divide the total findings by the total
extracted prose words and multiply by 100,000. An answer can contribute more
than one finding. This uses the plugin's own rules, so it measures its targets.
Overall writing quality and humanizer's other goals require separate evaluation.
The human baseline also contains checker matches.

**Answers with an em dash or spaced double hyphen.** Search extracted prose
for `—` or whitespace followed by `--` followed by whitespace. Count matching
answers once. Ordinary hyphens and en dashes are excluded. This search operates
independently of the Grounded Copy checker.

**Distinct digit strings per answer.** Search extracted prose with
`\d[\d,]*(?:\.\d+)?`, remove commas from matches, and count distinct strings
within each answer. Repeated `20` counts once; `1,000` and `1000` count as the
same string; `1` and `1.0` remain different. Written-out numbers are missed.
Ranges and dates can yield multiple strings. This metric counts text strings.
Retention of digit strings does not prove preservation
of facts, units, negation, or correctness.

## Recount and provenance

`python -I -B audit.py` verifies the inventory in manifest.json, the source
hashes of bundled files, answer/log alignment, runtime settings, and the
fixed native rewrite prefix. It recomputes the reported performance and style
figures. The historical reference-proof.json is retained for equality checks
on the existing style and timing rows. The corrected complete-path token
figures are stored in results.json.

Every execution record identifies its selected log and final answer file.
Each outer attempt has an original log hash and a normalized log hash. Public
normalization replaces Windows filesystem paths and session IDs with
placeholders. Original log bytes remain with the maintainer; their hashes
alone do not independently authenticate those bytes. The generated answer
files and raw answer JSONL files preserve their original bytes. Source scripts
under source/ are archived with paths replaced; audit.py is the portable entrypoint.

Original question and human-answer licenses and attribution are recorded per
item. The human passages are extracted prose, and that transformation is
marked. Missing author information is explicitly recorded. Code licensing
is in licenses/AGPL-3.0.txt; the humanizer file carries its MIT notice.

The experiment is internally produced and scored. Public recountability and
independent certification are separate statuses. Factual accuracy, reader
preference, other models, other languages, and long conversations were not
evaluated in this run.
