# Grounded Copy: the October 2026 experiment

Grounded Copy wrote each answer in one pass. The comparison workflow wrote a
plain answer and then edited it with humanizer. Across the same 100 questions,
the recorded paths had similar answer lengths. Grounded Copy recorded 36.4%
fewer tokens and a 40.2% lower median time than the two-step workflow.

These are measurements from this sample. Logged tokens are a cost proxy.
The run has incomplete billing and failed-attempt token records. Timing includes
retries and service delays.

Method: gpt-6.1-sol, Medium effort, Codex CLI 0.161.0, fresh isolated sessions;
Grounded Copy 0.7.0 and humanizer 3.1.0. The three columns use the same 100
questions, with 20 from each of five sites. The plain and Grounded Copy arms
also have a separate comparison over all 300 questions.

## Complete paths: the same 100 questions

| Measurement | Plain answer | Grounded Copy | Plain answer, then humanizer |
|---|---:|---:|---:|
| Logged tokens per finished answer, mean | 22,440.59 | 23,500.54 | 36,957.38 |
| Recorded path seconds, median | 47.3 | 42.9 | 71.7 |
| Full-answer words, mean | 305.8 | 303.2 | 312.8 |
| Extracted prose words, mean | 280.1 | 283.8 | 287.0 |

The token total for the rewrite workflow adds its first answer and its rewrite.
The 14,516.79-token rewrite step is included in 36,957.38. Grounded Copy recorded
4.7% more tokens than plain generation in this 100-question subset.

Full-answer words are counted by splitting the final answer on whitespace.
The prose count uses the original experiment's extraction rules.

## Style measurements: the same 100 questions

| Measurement | Plain answer | Grounded Copy | Plain answer, then humanizer |
|---|---:|---:|---:|
| Answers with a Grounded Copy checker match | 68.0% | 18.0% | 45.0% |
| Checker findings per 100,000 prose words | 417.7 | 70.5 | 177.7 |
| Answers with an em dash or spaced double hyphen | 71.0% | 37.0% | 1.0% |

The first two rows measure Grounded Copy 0.7.0's own rules. Some matches occur
in appropriate writing. Humanizer's own goals include reducing dashes, and its
rewrite had the lowest dash frequency here. The dash count runs independently
of Grounded Copy's checker.

## Verify the records

Run `python -I -B audit.py` with Python 3.10 or later. It checks the file hashes
and recounts both comparisons from the bundled answers and normalized logs.
It checks the matching question IDs, runtime settings, and selected executions.

[METHOD.md](METHOD.md) defines every metric and its limits.
[RESULTS.md](RESULTS.md) contains the full 300-question comparison and the
failure ledger. [results.json](results.json) holds the machine-readable figures.

The data includes all 700 generated answers and the 310 extracted human
answers. Questions and human passages carry source links and their original
licenses in each record. The tested checker and both skills are pinned by hash.
Public logs replace local filesystem paths and session IDs with placeholders;
the hashes of their original files are recorded separately.

The bundle enables a public recount after publication. It records an internal
experiment; independent certification and reader-quality assessment remain open.
