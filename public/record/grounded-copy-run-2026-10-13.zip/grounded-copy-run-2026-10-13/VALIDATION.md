# Local validation, 2026-10-13

The bundle passed its portable recount on Python 3.14. It contains 300 plain
answers, 300 Grounded Copy answers, 100 humanizer rewrites, and 310 extracted
human answers. Both comparison tables use matching question IDs.

The recount reproduced every original style and timing figure. It added the
complete-path token totals and full-answer length measurements. The sampled
workflow's recorded time adds the two stages per question before taking the
median. The token total uses the selected log footer for each stage.

The integrated self-check covered adding both stages, rejecting a missing
token footer, counting distinct digit strings, and the dash definition. A
separate tamper check modified an answer data file and confirmed that hash
validation rejected it before counting. Its temporary folder was removed.

Every shipped text file was scanned for private Windows paths, profile paths,
API-key patterns, bearer credentials, and JWT-like secrets. The scan passed.
Public log normalization preserves source URLs and replaces local paths and
session identifiers. The generated answer records preserve the source bytes.
Every question and human passage has a source URL and a recorded license.

The bundle builder verified that every file in the original matched experiment
directory kept its initial SHA-256. The original hashes are recorded in
original-hashes.json. Author identity is marked unavailable where the source
dump supplies neither a profile nor a display name.

Grounded Copy's prose check passed for the authored reports. A focused AI
review of the accounting and claims found no material blockers. That review
does not constitute independent certification or an assessment of answer
quality. The review left privacy, attribution, and tamper verification to
the checks described here.

No new answer generation was run for this export. Publication remains pending
the maintainer's instruction.
