# Complete results

The table uses the same question IDs in each condition. Logged tokens count selected successful executions. Recorded time includes the preserved retry and service delays.

## Same 300 questions

| Measurement | Plain answer | Grounded Copy |
|---|---:|---:|
| Logged tokens per finished answer, mean | 22870.7 | 23083.75 |
| Recorded path seconds, median | 46.8 | 41.6 |
| Full-answer whitespace words, mean | 291.1 | 291.9 |
| Full-answer characters, mean | 2167.8 | 2187.1 |
| Extracted prose words, mean | 273.8 | 276.3 |
| Answers with a Grounded Copy checker match (%) | 63.7 | 14.0 |
| Checker findings per 100,000 prose words | 409.1 | 55.5 |
| Answers with an em dash or spaced double hyphen (%) | 69.7 | 37.7 |
| Distinct digit strings per answer, mean | 3.2 | 3.5 |

### Attempt accounting

| Measurement | Plain answer | Grounded Copy |
|---|---:|---:|
| Selected outer executions | 300 | 300 |
| Workflow outer attempts, including retries | 307 | 307 |
| Unselected workflow attempts | 7 | 7 |
| Unselected attempts with missing token footers | 4 | 0 |
| Known printed tokens from unselected workflow attempts | 71528 | 66470 |
| Excluded activation probe attempts | 0 | 0 |
| Printed tokens from excluded activation probes | 0 | 0 |

## Same 100 questions

| Measurement | Plain answer | Grounded Copy | Plain answer, then humanizer |
|---|---:|---:|---:|
| Logged tokens per finished answer, mean | 22440.59 | 23500.54 | 36957.38 |
| Recorded path seconds, median | 47.3 | 42.9 | 71.7 |
| Full-answer whitespace words, mean | 305.8 | 303.2 | 312.8 |
| Full-answer characters, mean | 2269.4 | 2262.5 | 2215.1 |
| Extracted prose words, mean | 280.1 | 283.8 | 287.0 |
| Answers with a Grounded Copy checker match (%) | 68.0 | 18.0 | 45.0 |
| Checker findings per 100,000 prose words | 417.7 | 70.5 | 177.7 |
| Answers with an em dash or spaced double hyphen (%) | 71.0 | 37.0 | 1.0 |
| Distinct digit strings per answer, mean | 3.8 | 4.1 | 3.8 |

### Attempt accounting

| Measurement | Plain answer | Grounded Copy | Plain answer, then humanizer |
|---|---:|---:|---:|
| Selected outer executions | 100 | 100 | 200 |
| Workflow outer attempts, including retries | 101 | 100 | 207 |
| Unselected workflow attempts | 1 | 0 | 7 |
| Unselected attempts with missing token footers | 1 | 0 | 7 |
| Known printed tokens from unselected workflow attempts | 0 | 0 | 0 |
| Excluded activation probe attempts | 0 | 0 | 3 |
| Printed tokens from excluded activation probes | 0 | 0 | 31349 |

## Human reference

The 310 extracted human answers cover the same 300 questions. The checker flags 20.0%; their mean prose length is 172.4 words.

## Scope

The two-step workflow combines the recorded plain generation and its later rewrite. This is a reconstructed per-question path across separate batches. Audits and setup time are experiment overhead. Missing failed-attempt token footers prevent a complete billing calculation.

The two complete generation arms used Medium. The historical default-effort baseline is excluded. The style scanner remains pinned to Grounded Copy 0.7.0. No new model generation was used to prepare this bundle.
